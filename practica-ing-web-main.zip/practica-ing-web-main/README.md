# practica - Ingenieria Web

## Paso 1 
Descargar el proyecto de github

## Paso 2 
Instalar Laravel en la carpeta del proyecto

## Paso 3
Crear los modelos segun la siguiente tabla

|Producto|
|--------|
| (pk) id |
| Nombre (cadena) |
| Precio (decimal) |
| MarcaId (intero) |
| descripcion (cadena) |

## paso 4 
Crear ina interfaz de administracion para la tabla (CRUD)

## Paso 5
Subir los cambios al reposition en una rama con el nombre

Practica-{codido de estudiante} ejemplo: Practia-1920211

## Extra

5 Puntos extra si agregan el campo imagen y la funcionalidad de subir imagen desde el cliente.
